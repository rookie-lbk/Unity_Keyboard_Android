package com.mopsicus.umi;

public interface KeyboardObserver {
    void onKeyboardHeight(int height, int keyboardHeight, int orientation);
}
