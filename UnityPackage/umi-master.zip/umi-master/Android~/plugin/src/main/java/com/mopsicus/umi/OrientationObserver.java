package com.mopsicus.umi;

public interface OrientationObserver {
    void onOrientationChanged(int orientation);
}

