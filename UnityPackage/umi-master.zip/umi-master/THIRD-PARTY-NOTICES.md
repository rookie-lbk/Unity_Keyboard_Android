# Third-party software notices and information

This package contains third-party software components governed by the license(s) indicated below:

### NiceJson

[MIT License](https://github.com/AngelQuirogaM/NiceJson/blob/master/LICENSE)