# Change Log

All notable changes to this project will be documented in this file.

## [2.0.5] - 2024-12-10
- ### Added
- Set caret position

## [2.0.4] - 2024-09-10
- ### Added
- Change keyboard language

## [2.0.3] - 2024-08-28
- ### Added
- Custom text selection color (Android)

## [2.0.2] - 2024-08-27
- ### Added
- Custom caret/cursor/handles color
- Methods for more flexible keyboard height control #114
- ### Fixed
- Prevent double field initialization

## [2.0.1] - 2024-05-02
- ### Fixed
- Keyboard autohide on tap #110

## [2.0.0] - 2024-03-26
### Release v2